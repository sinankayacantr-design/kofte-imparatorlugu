KÖFTE İMPARATORLUĞU v2.5

Yayınlama:
1. GitHub'daki kofte-imparatorlugu deposunu aç.
2. Mevcut index.html dosyasını yedekle.
3. Bu paketteki index.html dosyasını depo ana dizinine yükle ve eskisinin üzerine yaz.
4. Commit changes ile kaydet.
5. GitHub Pages güncellendikten sonra oyunu yenile.

Not: Bu güncelleme mevcut yerel kayıt anahtarını korur; eski oyun ilerlemesini silmez.
